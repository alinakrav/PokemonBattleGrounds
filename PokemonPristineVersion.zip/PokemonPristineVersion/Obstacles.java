import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This class is for multiple obstacles, meaning you can't walk on them.
 * 
 * @author Kathy Zhuang
 */
public class Obstacles extends Objects
{
    public void collide() {
    }
}
