import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Trainer5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trainer4 extends Trainers
{    
    public Trainer4()
    {
        setImage(new GreenfootImage("Webp.net-resizeimage (11).png"));
    }    
}