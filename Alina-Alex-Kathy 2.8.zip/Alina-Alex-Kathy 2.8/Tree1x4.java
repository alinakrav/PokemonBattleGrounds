import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Tree1x3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tree1x4 extends Trees
{
    /**
     * Act - do whatever the Tree1x3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Tree1x4(){       
         setImage(new GreenfootImage("1x4.png"));
    } 
}
