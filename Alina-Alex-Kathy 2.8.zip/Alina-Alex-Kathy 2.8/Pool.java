import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Pool here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pool extends Obstacles
{
    public Pool(){
        setImage(new GreenfootImage("pool.png"));
    }
}
