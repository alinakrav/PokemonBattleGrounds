import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Tree4x2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tree4x2 extends Trees
{
    /**
     * Act - do whatever the Tree4x2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Tree4x2(){       
         setImage(new GreenfootImage("tree 4x2.png"));
    }
}
