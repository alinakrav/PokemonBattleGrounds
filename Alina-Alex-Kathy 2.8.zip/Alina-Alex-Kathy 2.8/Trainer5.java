import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Trainer5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trainer5 extends Trainers
{
    
    public Trainer5()
    {
        setImage(new GreenfootImage("Webp.net-resizeimage (9).png"));
    }    
}
