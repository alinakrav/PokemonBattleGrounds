import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Obstacle1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tree1x1 extends Trees
{
    /**
     * Act - do whatever the Obstacle1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Tree1x1(){       
         setImage(new GreenfootImage("tree 1x1.png"));
    }    
}
