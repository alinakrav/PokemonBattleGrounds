import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Tree2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tree1x2 extends Trees
{
    /**
     * Act - do whatever the Tree2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Tree1x2(){       
         setImage(new GreenfootImage("tree 1x2.png"));
    }   
}
