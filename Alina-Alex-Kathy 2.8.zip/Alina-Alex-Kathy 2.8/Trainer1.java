import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Trainer1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trainer1 extends Trainers
{
    /**
     * Act - do whatever the Trainer1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Trainer1() 
    {
        setImage(new GreenfootImage("Webp.net-resizeimage (10).png"));
    }   
}
