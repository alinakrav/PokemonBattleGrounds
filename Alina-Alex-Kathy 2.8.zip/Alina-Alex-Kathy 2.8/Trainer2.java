import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Tainer2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trainer2 extends Trainers
{
    /**
     * Act - do whatever the Tainer2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Trainer2() 
    {
        setImage(new GreenfootImage("trainer 1.png"));
    }    
}
