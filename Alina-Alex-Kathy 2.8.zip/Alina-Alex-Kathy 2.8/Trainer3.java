import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
/**
 * Write a description of class Trainer5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trainer3 extends Trainers
{
    
    public Trainer3()
    {
        setImage(new GreenfootImage("Webp.net-resizeimage (12).png"));
    }    
}